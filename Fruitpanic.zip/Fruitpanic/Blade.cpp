#include "Blade.h"
#include <graphics.h>
#include <windows.h>
#include <vector>
#include <utility>


//for in blade.cpp is just update the blade,shape,color and the locate



using namespace std;

// Used to store trajectory points
static vector<pair<int, int>> trail;

// update mouse location
void Blade::update() {
    if (GetAsyncKeyState(VK_LBUTTON) & 0x8000) {
        int mx = mousex();
        int my = mousey();

       
        lastX = curX;
        lastY = curY;
        curX = mousex();
        curY = mousey();
        active = true;

        // add waypoint
        trail.push_back({curX, curY});
        if (trail.size() > 10) //to control the blade trail size  （5）（10）（>25)langging
            trail.erase(trail.begin());
    
} else {
        active = false;
        trail.clear();
    }
}

// Draw the gleam of a blade
void Blade::draw() {
    if (!active || trail.size() < 1) return;

    // Draw from tail to head, with the color gradually becoming lighter
    for (size_t i = 1; i < trail.size(); ++i) {
        int x1 = trail[i - 1].first;
        int y1 = trail[i - 1].second;
        int x2 = trail[i].first;
        int y2 = trail[i].second;

        // Control the degree of fading (the closer to the tail, the lighter it is)
        int fade = 255 - (int)((float)i / trail.size() * 255);

        // Set the knife light color (white to light blue)
       // COLOR(200 - fade / 2, 200 - fade, 255);blue
        int color = COLOR(200 - fade / 2, 200 - fade, 255);
//COLOR(255, 80 - fade / 2, 80 - fade); red
//COLOR(80 - fade, 255, 80 - fade / 2); green
//COLOR(200, 80, 255 - fade / 2);purple
//COLOR(255, 220 - fade / 2, 120 - fade); gold
        setcolor(color);
        setlinestyle(SOLID_LINE, 0, 5);//blade size(2,3)(>8)

        // draw line
        line(x1, y1, x2, y2);

        // Sharp point effect: draw highlights on the front end
        if (i == trail.size() - 1) {
            setfillstyle(SOLID_FILL, WHITE);
            fillellipse(x2, y2, 4, 2);
        }
    }
}
