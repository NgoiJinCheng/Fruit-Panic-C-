#include "GameObject.h"
#include "Blade.h"


//for this ifle GameObject.cpp defines the basic movement behavior shared by all game objects (fruits, bombs, etc.).
//It updates the position (x, y) of the object each frame based on its velocity (vx, vy).
void GameObject::update() {
    x += vx;
    y += vy;

    //gravity
    vy+=1;//1.5，0.5
    
}
