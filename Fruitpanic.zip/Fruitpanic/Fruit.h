#ifndef FRUIT_H
#define FRUIT_H


//This header file defines the Fruit class, which represents the fruit objects in your Fruit Ninja game.
//1.It inherits from GameObject and provides specific functions for:
//2.how a fruit is initialized (position, speed, and random type),
//3.how it is drawn on the screen, and
//4.how it detects slicing when hit by the blade.
#include "GameObject.h"
#include "Blade.h"
#include "Score.h"

//This means Fruit inherits from GameObject, so it shares the same structure as other moving objects (like bombs).
class Fruit : public GameObject {
private:
//Stores the image file name (like "image/apple.bmp").
    char filename[50];
    int pointValue;
    
public:
//Sets a default image for the fruit when the object is first created.
    Fruit() { strcpy(filename, "image/fruit1.gif"); }
    int getPointValue() const;

    //Virtual Function
    void init(int px, int py, int pvx, int pvy) override;
    void draw() override;
    bool checkSlice(const Blade &blade) override;
};




#endif
