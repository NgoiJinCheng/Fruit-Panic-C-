#include "Particle.h"
#include <graphics.h>
#include <stdlib.h>
//The Particle class creates small red dots that simulate juice splashes when a fruit is sliced.
//Each particle has its own position, velocity, and lifetime, creating a short-lived burst effect.
void Particle::init(int px, int py) {
    x = px; y = py;
    vx = rand()%10 - 5;
    vy = rand()%10 - 5;
    lifetime = 20 + rand()%10;
    active = true;
}

void Particle::update() {
    if (!active) return;
    x += vx;
    y += vy;
    vy += 1; 
    lifetime--;
    if (lifetime <= 0) active = false;
}

void Particle::draw() {
    if (!active) return;
    setcolor(RED);
    circle(x, y, 2);
    floodfill(x, y, RED);
}
