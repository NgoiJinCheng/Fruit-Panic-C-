#ifndef GAME_H
#define GAME_H

#include <vector>
#include "GameObject.h"
#include "Fruit.h"
#include "Bomb.h"
#include "Particle.h"
#include "Blade.h"
#include "Score.h"

//Game.h=all in one
//Game.h defines the Game class, which is the core controller of your Fruit Ninja project.
//It manages everything in the game
class Game {
private:
//using polymorphism relationship
//Aggregation
    std::vector<GameObject*> objects;
    std::vector<Particle> particles;

    Blade blade;//using composition relationship(blade and score)
    //int score;
    Score score;

    bool running;
     int spawnTimer;
     int lives;
  bool paused;
 bool restartRequested = false;  

  
public:
    Game();
    ~Game();
    void spawnObject();
    void update();
    void render();
    void run();
    void showGameOverScreen();
    void showStartScreen();

  



};

#endif
