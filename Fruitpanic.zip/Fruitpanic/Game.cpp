#include "Game.h"
#include "Score.h"
#include <graphics.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>
#include <mmsystem.h>
#pragma comment(lib, "winmm.lib")
const int PAUSE_X1 = 10;
const int PAUSE_Y1 = 420;
const int PAUSE_X2 = 50;
const int PAUSE_Y2 = 460;
//for this file Game.cpp is the main logic controller of Fruit Ninja game.
//1.It controls the overall game flow, including:
//2.when and how fruits/bombs appear,
//3.how the blade interacts with them,
//4.how score and lives are updated,
//5.and what happens when the game ends (Game Over screen, restart, or exit).

//Constructor & Destructor
//---------------------------------------------------------------------------------
Game::Game() : score(20,20), running(true), paused(false),  spawnTimer(0),lives(3),restartRequested(false) {
    srand(time(NULL));
    particles.resize(100);
}
//aggregation created dynamically
//destroyed manually
Game::~Game() {
    for(auto obj : objects) delete obj;
}
//---------------------------------------------------------------------------------
//from agregation 
void Game::spawnObject() {
    //Randomly generates either a fruit or a bomb.
    int r = rand()%100;//0-99%
    GameObject* obj;
    //use Inheritance(fruit/bomb ->game object)
    //30% chance of spawning a bomb.
    if (r<30) obj = new Bomb();

    else obj = new Fruit();
    //Randomly generates either a fruit or a bomb.
    obj->init(
    rand()%600+100,480, //x and y location
    rand()%11-5,//speed  //5-2
    -(rand()%15+20));//spawn height  (8,12)(20,30)
    //Adds the object into a vector list for updating.
    objects.push_back(obj);
}

void Game::update() {
if (GetAsyncKeyState(VK_LBUTTON) & 0x8000) {
        int mx = mousex();
        int my = mousey();

        if (mx >= PAUSE_X1 && mx <= PAUSE_X2 &&
            my >= PAUSE_Y1 && my <= PAUSE_Y2) {

            paused = !paused;     // change pause
            delay(200);           // avoid straight tick

            // wait user mouse not tick
            while (GetAsyncKeyState(VK_LBUTTON) & 0x8000)
                delay(10);
        }
    }

    // ---------- IF PAUSED ----------
    if (paused) {
        return;   // not update any game logic
    }
    



    spawnTimer++;
    if (spawnTimer > 5) { // Generate a fruit or bomb every 20 frames
        spawnObject();
        spawnTimer = 0;
    }

    //______________Blade logic______________
    blade.update(); // update the blade locate

    // update splash
    for (auto &p : particles) p.update();

    // update fruit locate
   // for (auto obj : objects) {
        //use inheritnance function
    //    if (obj->isActive()) obj->update();
  //  }



  //std::vector<GameObject*> objects; using at there
  for (auto obj : objects) {
    if (!obj->isActive()) continue;

    obj->update();

    // out of screen it was no valid
    if (obj->getY() > 520) {
        obj->deactivate();
    }
}



//______________slide detection_________________
    // check fruit and bomb

    //we using dynamic_cast checks actual object type at runtime(fruit or bomb)
    //Allows different logic for different subclasses
    for (auto obj : objects) {
        if (!obj->isActive()) continue;

        if (Fruit* f = dynamic_cast<Fruit*>(obj)) {
            if (f->checkSlice(blade)) {
                //score++;  // cut fruit to get mark;
                score.add(f->getPointValue());

               PlaySound("image/slidefruit.wav", NULL,
          SND_FILENAME | SND_ASYNC);
                for (auto &p : particles) {
                    if (!p.active) {
                        p.init(f->getX(), f->getY());
                        break;
                    }
                }
            }
        }else if (Bomb* b = dynamic_cast<Bomb*>(obj)) {

            //using association   
    if (!b->checkSlice(blade)) {
        lives--; // minus 1 live

        PlaySound("image/hitbomb.wav", NULL,
          SND_FILENAME | SND_ASYNC);

       
        if (lives <= 0) {
            lives=0;
            running = false; //three time and end game
            // stop all,and avoid lag

PlaySound("image/gameover.wav", NULL,
              SND_FILENAME | SND_ASYNC);

    for (auto obj : objects) obj->deactivate();
        }
    }
}}
//____________________________________________________________________
}

 //Draws the background, all fruits, bombs, and blade.
   //Then displays the score and remaining lives on screen.
   //---------------------------------------------------------------------------
void Game::render() {

    // set black color background
    //setbkcolor(BLACK);
    cleardevice();
     // draw background
    readimagefile("image/background.gif", 0, 0, 800, 480);

    // draw object
    for (auto obj : objects)
        if (obj->isActive()) obj->draw();

    for (auto &p : particles)
        p.draw();

    blade.draw();

    
    // show score
   score.draw();

    // show live
    int baseX = 650, baseY = 10;
    int spacing = 50;

    for (int i = 0; i < 3; i++) {
        if (i < (3 - lives)) {
            readimagefile("image/red_x.gif",
                          baseX + i*spacing, baseY,
                          baseX + i*spacing + 40, baseY + 40);
        } else {
            char bombFile[20];
            sprintf(bombFile, "image/bomb%d.gif", i+1);
            readimagefile(bombFile,
                          baseX + i*spacing, baseY,
                          baseX + i*spacing + 40, baseY + 40);
        }
    }
    int pauseX1 = 10, pauseY1 = 420, pauseX2 = 50, pauseY2 = 460;
readimagefile("image/pausebutton.gif", pauseX1, pauseY1, pauseX2, pauseY2);

if (paused) {
    setfillstyle(SOLID_FILL, BLACK);
    bar(200, 180, 600, 300);

    readimagefile("image/pause.gif",
                  300, 200,   // left corner
                  500, 300);//right corner
}
}



void Game::showStartScreen() {
    // Loop start screen music
PlaySound("image/startscreen.wav", NULL,
          SND_FILENAME | SND_ASYNC | SND_LOOP);
    cleardevice();
    setbkcolor(BLACK);

    // Title image
    readimagefile("image/Title.gif",
                  150, 10,
                  650, 260);

    //  Start button image
    int btnLeft   = 300;
    int btnTop    = 260;
    int btnRight  = 500;
    int btnBottom = 320;

    readimagefile("image/startbutton.gif",
                  btnLeft, btnTop,
                  btnRight, btnBottom);

    //  Wait for click
    while (true) {
        if (GetAsyncKeyState(VK_LBUTTON) & 0x8000) {
            int mx = mousex();
            int my = mousey();

            // Click inside button image
            if (mx >= btnLeft && mx <= btnRight &&
                my >= btnTop  && my <= btnBottom) {

   // stop start screen music
    PlaySound(NULL, 0, 0);

    // play click start sound
    PlaySound("image/afterclickstartgame.wav", NULL,
              SND_FILENAME | SND_ASYNC);

                delay(200);   // prevent double click
                return;       // start game
            }

            while (GetAsyncKeyState(VK_LBUTTON) & 0x8000)
                delay(10);
        }
        delay(50);
    }
}


//---------------------------------------------------------------------------------------------------------



//void Game::run() {
  //  int page = 0;
   // while (running) {
     //   setactivepage(page);
       // setvisualpage(1 - page);
        //cleardevice();

        //update();
        //render();

        //page = 1 - page;
        //delay(30);
   // }

    //setactivepage(0);
    //setvisualpage(0);
    //cleardevice();
    //showGameOverScreen();
//}
void Game::run() {
    int page = 0;

    do {
        running = true;       // game status
        restartRequested = false; 

        while (running) {
            setactivepage(page);
            setvisualpage(1 - page);
            cleardevice();

            update();
            render();

            page = 1 - page;
            delay(30);
        }

        // display Game Over
        setactivepage(0);
        setvisualpage(0);
        cleardevice();
        showGameOverScreen();

        // if player click Restart，restartRequested = true
        if (restartRequested) {
            // Reset game objects
            for (auto obj : objects) delete obj;
            objects.clear();
            for (auto &p : particles) p.active = false;
            score.reset();
            lives = 3;
        }

    } while (restartRequested);  // player click  Restart,it will do action restart 
}



//Displays a simple Game Over screen
void Game::showGameOverScreen() {

    // ---------- Restart button area ----------
int restartX1 = 250;
int restartY1 = 270;   
int restartX2 = 400;
int restartY2 = 320;

// ---------- Exit button area ----------
int exitX1 = 420;
int exitY1 = 270;      
int exitX2 = 570;
int exitY2 = 320;

    cleardevice();
    setbkcolor(BLACK);
    // Game Over image title
readimagefile("image/gameover.gif",
              200, 80,
              600, 200);

      // show score
    // ---------- Draw score.bmp + digits ----------
Score gameOverScore(300, 210);  // adjust location score
gameOverScore.reset();
gameOverScore.add(score.getValue()); 
gameOverScore.draw();


    settextstyle(DEFAULT_FONT, HORIZ_DIR, 2);
    setfillstyle(SOLID_FILL, DARKGRAY);
    setcolor(WHITE);

    // Restart button
    readimagefile("image/replay.gif",
             restartX1, restartY1,
              restartX2, restartY2);

    // Exit button
    readimagefile("image/exit.gif",
             exitX1, exitY1,
              exitX2, exitY2);

    // wait user click which button(restart ,exit)
    while (true) {
        if (GetAsyncKeyState(VK_LBUTTON) & 0x8000) {
            int mx = mousex();
            int my = mousey();

            // Restart
            if (mx >= 250 && mx <= 400 && my >= 250 && my <= 300) {
                // status restart game
                 PlaySound("image/afterclickstartgame.wav", NULL,
              SND_FILENAME | SND_ASYNC);
                for (auto obj : objects) delete obj;
                objects.clear();
                for (auto &p : particles) p.active = false;
               // score = 0;

               score.reset();  //using score logic
             
                lives = 3;
                running = true;
                delay(200);
                restartRequested = true;
               // run();
                return;
            }

            // status Exit
            if (mx >= 420 && mx <= 570 && my >= 250 && my <= 300) {
                closegraph();
                exit(0);
            }

            // avoid its show again
            while (GetAsyncKeyState(VK_LBUTTON) & 0x8000)
                delay(10);
        }
        delay(50);
    }
}


