#include "Bomb.h"
#include <graphics.h>
#include <cstring>
#include <math.h>
#include "Blade.h"


//for bomb.cpp This file defines how a bomb object behaves in  Fruit Ninja game.
//It controls how the bomb appears, how it moves, and how it reacts when sliced by the player’s blade.
void Bomb::init(int px, int py, int pvx, int pvy) {
    GameObject::init(px, py, pvx, pvy);
    std::strcpy(filename, "image/bomb.gif");
}
//in there we need to read bomb.bmp file
void Bomb::draw() {
    if (active) {
        readimagefile(filename, x - 40, y - 40, x + 40, y + 40);
    }
}

bool Bomb::checkSlice(const Blade &blade) {
    if (!active) return true; // If not active, it is considered not hit (subsequent judgment by the Game).
    
    int x0 = blade.lastX, y0 = blade.lastY;
    int x1 = blade.curX,  y1 = blade.curY;
    int cx = x, cy = y;

    int dx = x1 - x0;
    int dy = y1 - y0;
    if (dx == 0 && dy == 0) return true;

    float denom = float(dx*dx + dy*dy);
    if (denom == 0.0f) return true;

    float t = ((cx - x0) * dx + (cy - y0) * dy) / denom;
    if (t < 0.0f) t = 0.0f;
    if (t > 1.0f) t = 1.0f;

    int closestX = x0 + int(dx * t);
    int closestY = y0 + int(dy * t);

    int distSq = (closestX - cx)*(closestX - cx) + (closestY - cy)*(closestY - cy);
    if (distSq < 1600) { // 40px radius -> 40*40 = 1600
        active = false;
        return false; // Hit the bomb (return false to let the game handle losing a life or ending)
    }
    return true;
}
