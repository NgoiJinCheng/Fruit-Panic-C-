#ifndef GAMEOBJECT_H
#define GAMEOBJECT_H

#include <graphics.h>
//This file defines the base class GameObject, which provides the foundation for all movable objects in  Fruit Ninja game example fruits, bombs

class Blade; 

class GameObject {
protected:
//current position of the object.
    int x, y;
    //velocity (speed and direction) for horizontal and vertical movement.
    int vx, vy;
    //indicates whether the object is currently in play
    bool active;

public:
//The constructor initializes position and velocity to 0, and sets active to false
    GameObject() : x(0), y(0), vx(0), vy(0), active(false) {}
    virtual ~GameObject() {}

    //The init() method initializes the object’s starting position and velocity, and activates it.
    virtual void init(int px, int py, int pvx, int pvy) {
        x = px; y = py; vx = pvx; vy = pvy; active = true;
    }
    virtual void update();
    virtual void draw() = 0;
    virtual bool checkSlice(const Blade &blade) { return false; }


    //Utility Functions
    bool isActive() const { return active; }
    void deactivate() { active = false; }

    int getX() const { return x; }
    int getY() const { return y; }
};

#endif
