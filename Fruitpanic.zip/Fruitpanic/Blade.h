#ifndef BLADE_H
#define BLADE_H
//The Blade class represents the player’s slicing motion in the game.
//It tracks the current and previous mouse positions (curX, curY, lastX, lastY) to draw a blade trail when the player moves the mouse.
//It also determines when the blade is active (for example, when the left mouse button is pressed).
//In short, it’s responsible for detecting the slicing movement that can cut fruits or bombs.
class Blade {
public:
    int curX, curY, lastX, lastY;
    bool active;

 

    void update();
    void draw();
};

#endif
