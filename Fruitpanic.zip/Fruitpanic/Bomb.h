#ifndef BOMB_H
#define BOMB_H

#include "GameObject.h"
#include "Blade.h"
#include <cstring>
//Declares that Bomb inherits from GameObject.
class Bomb : public GameObject {
private:
//Stores the image filename (for example "image/bomb.bmp") used when drawing the bomb.
    char filename[50];
public:
//When a Bomb object is created, it automatically sets the default image path.
    Bomb() { std::strcpy(filename, "image/bomb.gif"); }
   // These are polymorphic functions (virtual + override)
    virtual void init(int px, int py, int pvx, int pvy) override;
    virtual void draw() override;
    virtual bool checkSlice(const Blade &blade) override;
};

#endif // BOMB_H
