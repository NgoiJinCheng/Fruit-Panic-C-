#ifndef PARTICLE_H
#define PARTICLE_H


//Particle.h defines the Particle class, which represents small pieces or droplets that appear when a fruit is sliced
class Particle {
public:
//Current position of the particle on screen
    int x, y;
    //Horizontal and vertical velocity.
    int vx, vy;
    //Determines how long the particle will stay visible
    int lifetime;
    //Whether the particle is currently active (visible).
    bool active;
//Constructor initializes all variables to default values
    Particle() : x(0), y(0), vx(0), vy(0), lifetime(0), active(false) {}
    //Sets position and random movement when fruit is sliced.
    void init(int px, int py);
    void update();
    void draw();
};

#endif
