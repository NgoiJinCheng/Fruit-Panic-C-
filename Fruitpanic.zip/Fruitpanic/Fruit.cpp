#include "Fruit.h"
#include <graphics.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "Blade.h"
#include "Score.h"

// init() — Initialize the Fruit
// ----------------------------------------------------------------------------------------
void Fruit::init(int px, int py, int pvx, int pvy) {
    GameObject::init(px, py, pvx, pvy);

    //fruit picture
    int r = rand() % 6; // 6 type fruit
    switch (r) {
        case 0: 
            strcpy(filename, "image/fruit1.gif"); 
            pointValue = 1;
            break;
        case 1: 
            strcpy(filename, "image/fruit2.gif"); 
            pointValue = 1;
            break;
        case 2: 
            strcpy(filename, "image/apple.gif"); 
            pointValue = 2;
            break;
        case 3: 
            strcpy(filename, "image/jelly.gif"); 
            pointValue = 3;
            break;
        case 4: 
            strcpy(filename, "image/peach.gif"); 
            pointValue = 2;
            break;
        case 5: 
            strcpy(filename, "image/watermelon.gif"); 
            pointValue = 5; // watermelon bonus
            break;
    }
}
// ----------------------------------------------------------------------------------------


// draw() — Display the Fruit
// ---------------------------------------------------------------------
void Fruit::draw() {
    if (active)
        readimagefile(filename, x-40, y-40, x+40, y+40);
}
// ---------------------------------------------------------------------


// checkSlice() — Detect When the Fruit is Cut
// ---------------------------------------------------------------
bool Fruit::checkSlice(const Blade &blade) {
    if (!active) return false;

    int x0 = blade.lastX, y0 = blade.lastY;
    int x1 = blade.curX, y1 = blade.curY;
    int cx = x, cy = y;

    int dx = x1 - x0;
    int dy = y1 - y0;
    if (dx == 0 && dy == 0) return false;

    float t = ((cx - x0) * dx + (cy - y0) * dy) / float(dx*dx + dy*dy);
    if (t < 0) t = 0;
    if (t > 1) t = 1;

    int closestX = x0 + dx * t;
    int closestY = y0 + dy * t;

    int dist = (closestX - cx)*(closestX - cx) + (closestY - cy)*(closestY - cy);

    if (dist < 1600) { // redius 40px
        active = false;
        return true;
    }
    return false;
}
// ---------------------------------------------------------------------


// ✅ Return point value so Game can add score
int Fruit::getPointValue() const {
    return pointValue;
}
