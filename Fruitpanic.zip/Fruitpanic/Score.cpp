#include "Score.h"
#include <graphics.h>
#include <cstdio>

Score::Score(int x, int y) {
    value = 0;
    scoreX = x;
    scoreY = y;

    scoreW = 287;
    scoreH = 80;
    digitW = 80;

    loadDigitHeights();
}

//control score location
void Score::loadDigitHeights() {
    digitHeight[0] = 108;
    digitHeight[1] = 126;
    digitHeight[2] = 109;
    digitHeight[3] = 112;
    digitHeight[4] = 108;
    digitHeight[5] = 112;
    digitHeight[6] = 115;
    digitHeight[7] = 109;
    digitHeight[8] = 114;
    digitHeight[9] = 111;
}

// plus score
void Score::add(int points) {
    value += points;
}

// reset
void Score::reset() {
    value = 0;
}

//show score
void Score::draw() {
    
    int targetH = 40;       
    float scaleLabel = (float)targetH / scoreH;  // score.bmp 

    // new location
    int newScoreW = scoreW * scaleLabel;
    int newScoreH = targetH;

    // show the small size score.bmp
    readimagefile("image/score.gif",
                  scoreX, scoreY,
                  scoreX + newScoreW, scoreY + newScoreH);

    // baseline
    int baselineY = scoreY + newScoreH;

    // score starting location
    int digitX = scoreX + newScoreW + 10;


    string s = to_string(value);

    
    for (char c : s) {
        int d = c - '0';

       
        float scaleDigit = (float)targetH / digitHeight[d];
        int newDigitW = digitW * scaleDigit;
        int newDigitH = targetH;

        int digitY = baselineY - newDigitH;

        char filename[50];
        sprintf(filename, "image/num%d.gif", d);

        readimagefile(filename,
                      digitX, digitY,
                      digitX + newDigitW, digitY + newDigitH);

        digitX += newDigitW + 3;  //space location
    }
}
