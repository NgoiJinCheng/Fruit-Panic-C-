#ifndef SCORE_H
#define SCORE_H

#include <graphics.h>
#include <string>
using namespace std;

class Score {
private:
    int value;

    int scoreX, scoreY;         // left up corner
    int scoreW, scoreH;         // score.bmp size）

    int digitW;                 // 80
    int digitHeight[10];       

public:
    Score(int x = 20, int y = 20);


    void loadDigitHeights();
    void add(int points);
    void reset();
    void draw();
    int getValue() const { return value; }
};

#endif
