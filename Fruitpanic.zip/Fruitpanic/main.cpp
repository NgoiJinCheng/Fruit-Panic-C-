#include <graphics.h>
#include "Game.h"


//for This file contains the main function, which initializes the graphics window, creates a Game object, and starts the game loop by calling run()
int main() {
    initwindow(800,480,"Fruit Panic UTM");
    Game game;
    game.showStartScreen();
    game.run();
    closegraph();
    return 0;
}
